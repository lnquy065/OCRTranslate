# OCRTranslate
An Android application using OCR API to translate screenshot

The PTIT D14CQCP01 Android Team
+ Luong Ngoc Quy
+ Thieu Quang Tuan
+ Nguyen Xuan Hieu
+ Tran Quoc Huy
+ Vo Quoc Binh
+ Nguyen Dang Khoa
